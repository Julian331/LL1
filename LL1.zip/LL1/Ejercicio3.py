# ANALIZADOR LÉXICO SIMPLE

entrada = []
pos = 0

def siguiente_token():
    global pos
    if pos < len(entrada):
        tok = entrada[pos]
        pos += 1
        return tok
    return "$"


# PARSER

token_actual = None

def error():
    raise Exception(f"Error de sintaxis con token: {token_actual}")


def emparejar(tok):
    global token_actual
    if token_actual == tok:
        token_actual = siguiente_token()
    else:
        error()


# FUNCIONES DE LA GRAMÁTICA

def S():
    A()
    B()
    C()
    Sp()


def Sp():
    global token_actual

    if token_actual == "uno":
        emparejar("uno")
        Sp()
    else:
        # ε
        pass


def A():
    global token_actual

    if token_actual == "dos":
        emparejar("dos")
        B()
        C()
    else:
        # ε
        pass


def B():
    global token_actual

    if token_actual == "cuatro":
        C()
        emparejar("tres")
    else:
        # ε
        pass


def C():
    global token_actual

    if token_actual == "cuatro":
        emparejar("cuatro")
        B()
    else:
        # ε
        pass


# FUNCIÓN PRINCIPAL

def analizar(cadena):
    global entrada, pos, token_actual

    entrada = cadena.split() + ["$"]
    pos = 0
    token_actual = siguiente_token()

    S()

    if token_actual == "$":
        print(" Cadena aceptada")
    else:
        error()


# PRUEBAS

if __name__ == "__main__":
    try:
        # Ejemplos válidos
        analizar("dos cuatro tres cuatro uno uno")
        analizar("cuatro tres")
        analizar("")

        # Ejemplo inválido
        analizar("uno cuatro")

    except Exception as e:
        print("invalido", e)
