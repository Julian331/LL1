# ANALIZADOR LÉXICO SIMPLE

entrada = []
pos = 0

def siguiente_token():
    global pos
    if pos < len(entrada):
        tok = entrada[pos]
        pos += 1
        return tok
    return "$"  # Fin de entrada


# PARSER

token_actual = None

def error():
    raise Exception(f"Error de sintaxis con token: {token_actual}")


def emparejar(tok):
    global token_actual
    if token_actual == tok:
        token_actual = siguiente_token()
    else:
        error()

# FUNCIONES DE LA GRAMÁTICA

def S():
    global token_actual

    if token_actual == "dos":
        emparejar("dos")
        C()
    elif token_actual in ["cuatro", "cinco", "siete", "uno"]:
        B()
        emparejar("uno")
    elif token_actual in ["$", "tres"]:
        # ε
        pass
    else:
        error()


def A():
    global token_actual

    if token_actual == "cuatro":
        emparejar("cuatro")
    elif token_actual in ["dos", "cinco", "siete", "tres"]:
        S()
        emparejar("tres")
        B()
        C()
    elif token_actual == "cinco":
        # ε
        pass
    else:
        error()


def B():
    global token_actual

    if token_actual in ["dos", "cuatro", "cinco", "siete"]:
        A()
        emparejar("cinco")
        C()
        emparejar("seis")
    elif token_actual in ["uno", "seis", "$"]:
        # ε
        pass
    else:
        error()


def C():
    global token_actual

    if token_actual == "siete":
        emparejar("siete")
        B()
    elif token_actual in ["seis", "$", "uno"]:
        # ε
        pass
    else:
        error()


# FUNCIÓN PRINCIPAL

def analizar(cadena):
    global entrada, pos, token_actual

    entrada = cadena.split() + ["$"]
    pos = 0
    token_actual = siguiente_token()

    S()

    if token_actual == "$":
        print(" Cadena aceptada")
    else:
        error()


# PRUEBAS

if __name__ == "__main__":
    try:
        # Ejemplos válidos
        analizar("dos siete cinco seis uno")
        analizar("uno")
        analizar("")

        # Ejemplo inválido
        analizar("dos cinco")

    except Exception as e:
        print("invalido", e)
