# ANALIZADOR LÉXICO SIMPLE

entrada = []
pos = 0

def siguiente_token():
    global pos
    if pos < len(entrada):
        tok = entrada[pos]
        pos += 1
        return tok
    return "$"  # Fin de cadena


# PARSER

token_actual = None

def error():
    raise Exception(f"Error de sintaxis con token: {token_actual}")


def emparejar(tok):
    global token_actual
    if token_actual == tok:
        token_actual = siguiente_token()
    else:
        error()
# FUNCIONES DE LA GRAMÁTICA

def S():
    global token_actual

    if token_actual in ["dos", "cuatro", "seis"]:
        A()
        B()
        C()
    elif token_actual == "uno":
        D()
        E()
    else:
        error()


def A():
    global token_actual

    if token_actual == "dos":
        emparejar("dos")
        B()
        emparejar("tres")
    else:
        # ε
        pass


def B():
    Bp()


def Bp():
    global token_actual

    if token_actual == "cuatro":
        emparejar("cuatro")
        C()
        emparejar("cinco")
        Bp()
    else:
        # ε
        pass


def C():
    global token_actual

    if token_actual == "seis":
        emparejar("seis")
        A()
        B()
    else:
        # ε
        pass


def D():
    global token_actual

    if token_actual == "uno":
        emparejar("uno")
        A()
        E()
    elif token_actual in ["cuatro", "seis", "tres", "$"]:
        B()
    else:
        error()


def E():
    global token_actual

    if token_actual == "tres":
        emparejar("tres")
    else:
        error()
# FUNCIÓN PRINCIPAL

def analizar(cadena):
    global entrada, pos, token_actual

    entrada = cadena.split() + ["$"]
    pos = 0
    token_actual = siguiente_token()

    S()

    if token_actual == "$":
        print(" Cadena aceptada")
    else:
        error()

# PRUEBAS

if __name__ == "__main__":
    try:
        # Ejemplos válidos
        analizar("dos cuatro cinco tres")
        analizar("uno tres")
        analizar("cuatro cinco")

        # Ejemplo inválido
        analizar("dos cinco")

    except Exception as e:
        print("invalido", e)
